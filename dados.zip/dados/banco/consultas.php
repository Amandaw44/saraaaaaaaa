<?php
/** @var PDO|NULL $con */

$con=null;
try{
    $con = new PDO("mysql:host=localhost;dbname=sistema_teste","root","bancodedados");
}catch(PDOException $e){
        echo $e->getMessage();
}
$sql="SELECT count(*) FROM usuarios where email = :mail";
$stmt = $con->prepare($sql);
$stmt->bindParam(':mail',$_GET['email']);
$stmt->execute();
$resultado = $stmt->fetchColumn();

if ($resultado > 0){
    echo "Ja existe esse email";
}else{
    echo "Email disponivel";
}
